# Online Store

Onlayn do'kon: mahsulotlarni ko'rish, savatchaga qo'shish va buyurtma berish imkonini beruvchi to'liq ilova (backend + frontend).

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — API serverni ishga tushirish (port 5000)
- `pnpm run typecheck` — barcha paketlarda to'liq typecheck
- `pnpm run build` — typecheck + build
- `pnpm --filter @workspace/api-spec run codegen` — OpenAPI spec'dan API hook va Zod sxemalarni qayta generatsiya qilish
- `pnpm --filter @workspace/db run push` — DB sxema o'zgarishlarini push qilish (faqat dev)
- Kerakli env: `DATABASE_URL` — Postgres ulanish satri

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validatsiya: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (OpenAPI spec'dan)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/api-server` — backend (routes: products, categories, cart, orders, store, health)
- `artifacts/store` — frontend do'kon sahifalari (Home, Products, Cart, Checkout, Orders)
- `artifacts/mockup-sandbox` — dizayn maketlari uchun alohida sandbox
- `lib/db` — DB sxemasi (products, categories, orders)
- `lib/api-spec/openapi.yaml` — API'ning yagona haqiqat manbai
- `lib/api-zod`, `lib/api-client-react` — shu spec'dan avtomatik generatsiya qilingan kod

## Architecture decisions

- Savatcha hozircha serverning xotirasida (RAM) saqlanadi, baza emas — server qayta ishga tushsa savatchalar yo'qoladi
- Foydalanuvchi cookie'dagi `cartSession` orqali aniqlanadi (login tizimi yo'q)
- Buyurtmalar `sessionId` orqali o'sha sessiyaga bog'lanadi — har kim faqat o'z buyurtmasini ko'radi

## Gotchas

- Savatchaga qo'shish va buyurtma berishda ombordagi son (`stock`) tekshiriladi va buyurtmadan keyin kamaytiriladi
- `DATABASE_URL` bo'lmasa server ishlamaydi

## Pointers

- `pnpm-workspace` skill — workspace tuzilishi va paket tafsilotlari uchun
