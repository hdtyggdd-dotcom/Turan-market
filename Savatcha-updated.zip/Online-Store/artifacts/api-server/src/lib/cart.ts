// In-memory cart store keyed by session ID
export interface CartItem {
  productId: number;
  quantity: number;
  name: string;
  price: number;
  originalPrice: number | null;
  imageUrl: string | null;
}

type CartStore = Map<string, CartItem[]>;

const cartStore: CartStore = new Map();

export function getCart(sessionId: string): CartItem[] {
  return cartStore.get(sessionId) ?? [];
}

export function setCart(sessionId: string, items: CartItem[]): void {
  cartStore.set(sessionId, items);
}

export function clearCart(sessionId: string): void {
  cartStore.set(sessionId, []);
}

export function computeCartTotals(items: CartItem[]) {
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const total = subtotal; // no tax/shipping for now
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);
  return { subtotal, total, itemCount };
}
