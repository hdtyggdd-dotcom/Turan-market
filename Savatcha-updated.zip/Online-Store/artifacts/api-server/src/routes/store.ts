import { Router, type IRouter } from "express";
import { db, productsTable, categoriesTable, ordersTable } from "@workspace/db";
import { count, eq } from "drizzle-orm";

const router: IRouter = Router();

router.get("/store/summary", async (_req, res): Promise<void> => {
  const [[products], [categories], [orders], [featured]] = await Promise.all([
    db.select({ cnt: count() }).from(productsTable),
    db.select({ cnt: count() }).from(categoriesTable),
    db.select({ cnt: count() }).from(ordersTable),
    db.select({ cnt: count() }).from(productsTable).where(eq(productsTable.featured, true)),
  ]);

  res.json({
    totalProducts: Number(products.cnt),
    totalCategories: Number(categories.cnt),
    totalOrders: Number(orders.cnt),
    featuredCount: Number(featured.cnt),
  });
});

export default router;
