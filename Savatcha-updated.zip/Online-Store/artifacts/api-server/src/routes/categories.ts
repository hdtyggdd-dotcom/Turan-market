import { Router, type IRouter } from "express";
import { db, categoriesTable, productsTable } from "@workspace/db";
import { count, eq } from "drizzle-orm";

const router: IRouter = Router();

async function ensureSystemCategories() {
  const systemCategories = [
    {
      name: "Aksiya",
      slug: "aksiya",
      description: "Chegirmadagi mahsulotlar",
      imageUrl: null,
    },
    {
      name: "Shikastlangan tovarlar",
      slug: "shikastlangan-tovarlar",
      description: "Holati ko‘rsatilgan shikastlangan mahsulotlar",
      imageUrl: null,
    },
  ];

  for (const category of systemCategories) {
    const [existing] = await db.select().from(categoriesTable).where(eq(categoriesTable.slug, category.slug)).limit(1);
    if (!existing) await db.insert(categoriesTable).values(category);
  }
}

router.get("/categories", async (_req, res): Promise<void> => {
  await ensureSystemCategories();

  const cats = await db.select().from(categoriesTable).orderBy(categoriesTable.name);
  const countRows = await db
    .select({ categoryId: productsTable.categoryId, cnt: count() })
    .from(productsTable)
    .groupBy(productsTable.categoryId);

  const countMap = new Map(countRows.map((r) => [r.categoryId, Number(r.cnt)]));
  res.json(cats.map((c) => ({
    id: c.id,
    name: c.name,
    slug: c.slug,
    description: c.description ?? null,
    imageUrl: c.imageUrl ?? null,
    productCount: countMap.get(c.id) ?? 0,
  })));
});

export default router;
