import { Router, type IRouter } from "express";
import { db, ordersTable, productsTable } from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";
import { getCart, clearCart } from "../lib/cart";

const router: IRouter = Router();

function getSessionId(req: any): string {
  return req.cookies?.cartSession ?? "";
}

router.get("/orders", async (req, res): Promise<void> => {
  const sessionId = getSessionId(req);
  const rows = sessionId
    ? await db
        .select()
        .from(ordersTable)
        .where(eq(ordersTable.sessionId, sessionId))
        .orderBy(desc(ordersTable.createdAt))
    : [];
  const result = rows.map((o) => ({
    ...o,
    total: Number(o.total),
    items: (o.items as any[]) ?? [],
    createdAt: o.createdAt.toISOString(),
  }));
  res.json(result);
});

router.post("/orders", async (req, res): Promise<void> => {
  const sessionId = getSessionId(req);
  const items = sessionId ? getCart(sessionId) : [];

  if (items.length === 0) {
    res.status(400).json({ error: "Cart is empty" });
    return;
  }

  const { customerName, customerEmail, shippingAddress } = req.body as {
    customerName: string;
    customerEmail: string;
    shippingAddress: string;
  };

  if (!customerName || !customerEmail || !shippingAddress) {
    res.status(400).json({ error: "customerName, customerEmail and shippingAddress are required" });
    return;
  }

  for (const item of items) {
    const [product] = await db.select().from(productsTable).where(eq(productsTable.id, item.productId));
    if (!product || product.stock < item.quantity) {
      res.status(400).json({ error: `"${item.name}" is no longer available in that quantity` });
      return;
    }
  }

  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const orderItems = items.map((item) => ({
    productId: item.productId,
    name: item.name,
    quantity: item.quantity,
    price: item.price,
    imageUrl: item.imageUrl,
  }));

  const [order] = await db
    .insert(ordersTable)
    .values({
      status: "pending",
      sessionId,
      total: total.toFixed(2),
      customerName,
      customerEmail,
      shippingAddress,
      items: orderItems,
    })
    .returning();

  for (const item of items) {
    await db
      .update(productsTable)
      .set({ stock: sql`${productsTable.stock} - ${item.quantity}` })
      .where(eq(productsTable.id, item.productId));
  }

  if (sessionId) clearCart(sessionId);

  res.status(201).json({
    ...order,
    total: Number(order.total),
    items: (order.items as any[]) ?? [],
    createdAt: order.createdAt.toISOString(),
  });
});

router.get("/orders/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid order id" });
    return;
  }

  const sessionId = getSessionId(req);
  const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, id));
  if (!order || !sessionId || order.sessionId !== sessionId) {
    res.status(404).json({ error: "Order not found" });
    return;
  }

  res.json({
    ...order,
    total: Number(order.total),
    items: (order.items as any[]) ?? [],
    createdAt: order.createdAt.toISOString(),
  });
});

export default router;
