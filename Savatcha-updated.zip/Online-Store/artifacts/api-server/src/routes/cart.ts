import { Router, type IRouter } from "express";
import { db, productsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getCart, setCart, clearCart, computeCartTotals, type CartItem } from "../lib/cart";

const router: IRouter = Router();

function getSessionId(req: any): string {
  // Use a simple cookie-based session ID; create one if absent
  if (!req.cookies?.cartSession) {
    const id = Math.random().toString(36).slice(2) + Date.now().toString(36);
    req._newCartSession = id;
    return id;
  }
  return req.cookies.cartSession as string;
}

function setSessionCookie(req: any, res: any, sessionId: string) {
  if (req._newCartSession) {
    res.cookie("cartSession", sessionId, {
      httpOnly: true,
      maxAge: 7 * 24 * 60 * 60 * 1000,
      sameSite: "lax",
    });
  }
}

function buildCartResponse(items: CartItem[]) {
  const { subtotal, total, itemCount } = computeCartTotals(items);
  return {
    items: items.map((item) => ({
      ...item,
      subtotal: item.price * item.quantity,
    })),
    subtotal,
    total,
    itemCount,
  };
}

router.get("/cart", async (req, res): Promise<void> => {
  const sessionId = getSessionId(req);
  setSessionCookie(req, res, sessionId);
  const items = getCart(sessionId);
  res.json(buildCartResponse(items));
});

router.delete("/cart", async (req, res): Promise<void> => {
  const sessionId = getSessionId(req);
  setSessionCookie(req, res, sessionId);
  clearCart(sessionId);
  res.json(buildCartResponse([]));
});

router.post("/cart/items", async (req, res): Promise<void> => {
  const sessionId = getSessionId(req);
  setSessionCookie(req, res, sessionId);

  const { productId, quantity } = req.body as { productId: number; quantity: number };
  if (!productId || !quantity || quantity < 1) {
    res.status(400).json({ error: "productId and quantity (>=1) required" });
    return;
  }

  const [product] = await db
    .select()
    .from(productsTable)
    .where(eq(productsTable.id, productId));

  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  const items = getCart(sessionId);
  const existing = items.find((i) => i.productId === productId);
  const requestedQty = (existing?.quantity ?? 0) + quantity;
  if (requestedQty > product.stock) {
    res.status(400).json({ error: `Only ${product.stock} left in stock` });
    return;
  }

  if (existing) {
    existing.quantity += quantity;
  } else {
    items.push({
      productId,
      quantity,
      name: product.name,
      price: Number(product.price),
      originalPrice: product.originalPrice != null ? Number(product.originalPrice) : null,
      imageUrl: product.imageUrl ?? null,
    });
  }
  setCart(sessionId, items);
  res.json(buildCartResponse(items));
});

router.patch("/cart/items/:productId", async (req, res): Promise<void> => {
  const sessionId = getSessionId(req);
  setSessionCookie(req, res, sessionId);

  const raw = Array.isArray(req.params.productId) ? req.params.productId[0] : req.params.productId;
  const productId = parseInt(raw, 10);
  const { quantity } = req.body as { quantity: number };

  if (isNaN(productId)) {
    res.status(400).json({ error: "Invalid productId" });
    return;
  }

  let items = getCart(sessionId);
  if (quantity <= 0) {
    items = items.filter((i) => i.productId !== productId);
  } else {
    const [product] = await db.select().from(productsTable).where(eq(productsTable.id, productId));
    if (!product) {
      res.status(404).json({ error: "Product not found" });
      return;
    }
    if (quantity > product.stock) {
      res.status(400).json({ error: `Only ${product.stock} left in stock` });
      return;
    }
    const existing = items.find((i) => i.productId === productId);
    if (existing) existing.quantity = quantity;
  }
  setCart(sessionId, items);
  res.json(buildCartResponse(items));
});

router.delete("/cart/items/:productId", async (req, res): Promise<void> => {
  const sessionId = getSessionId(req);
  setSessionCookie(req, res, sessionId);

  const raw = Array.isArray(req.params.productId) ? req.params.productId[0] : req.params.productId;
  const productId = parseInt(raw, 10);
  if (isNaN(productId)) {
    res.status(400).json({ error: "Invalid productId" });
    return;
  }

  const items = getCart(sessionId).filter((i) => i.productId !== productId);
  setCart(sessionId, items);
  res.json(buildCartResponse(items));
});

export default router;
