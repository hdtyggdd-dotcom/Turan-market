import { Router, type IRouter } from "express";
import { db, productsTable, categoriesTable } from "@workspace/db";
import { eq, ilike, gte, lte, desc, asc, and, type SQL } from "drizzle-orm";

const router: IRouter = Router();

router.get("/products", async (req, res): Promise<void> => {
  const { categoryId, search, minPrice, maxPrice, sort } = req.query as Record<string, string | undefined>;

  const conditions: SQL[] = [];
  if (categoryId) conditions.push(eq(productsTable.categoryId, parseInt(categoryId, 10)));
  if (search) conditions.push(ilike(productsTable.name, `%${search}%`));
  if (minPrice) conditions.push(gte(productsTable.price, minPrice));
  if (maxPrice) conditions.push(lte(productsTable.price, maxPrice));

  let query = db
    .select({
      id: productsTable.id,
      name: productsTable.name,
      slug: productsTable.slug,
      description: productsTable.description,
      price: productsTable.price,
      originalPrice: productsTable.originalPrice,
      stock: productsTable.stock,
      imageUrl: productsTable.imageUrl,
      categoryId: productsTable.categoryId,
      categoryName: categoriesTable.name,
      rating: productsTable.rating,
      reviewCount: productsTable.reviewCount,
      featured: productsTable.featured,
      createdAt: productsTable.createdAt,
    })
    .from(productsTable)
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .$dynamic();

  switch (sort) {
    case "price_asc":
      query = query.orderBy(asc(productsTable.price));
      break;
    case "price_desc":
      query = query.orderBy(desc(productsTable.price));
      break;
    case "newest":
      query = query.orderBy(desc(productsTable.createdAt));
      break;
    case "popular":
      query = query.orderBy(desc(productsTable.reviewCount));
      break;
    default:
      query = query.orderBy(desc(productsTable.createdAt));
  }

  const rows = await query;
  const result = rows.map((p) => ({
    ...p,
    price: Number(p.price),
    originalPrice: p.originalPrice != null ? Number(p.originalPrice) : null,
    rating: p.rating != null ? Number(p.rating) : null,
    images: p.imageUrl ? [p.imageUrl] : [],
    createdAt: p.createdAt.toISOString(),
  }));

  res.json(result);
});

router.get("/products/featured", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      id: productsTable.id,
      name: productsTable.name,
      slug: productsTable.slug,
      description: productsTable.description,
      price: productsTable.price,
      originalPrice: productsTable.originalPrice,
      stock: productsTable.stock,
      imageUrl: productsTable.imageUrl,
      categoryId: productsTable.categoryId,
      categoryName: categoriesTable.name,
      rating: productsTable.rating,
      reviewCount: productsTable.reviewCount,
      featured: productsTable.featured,
      createdAt: productsTable.createdAt,
    })
    .from(productsTable)
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .where(eq(productsTable.featured, true))
    .orderBy(desc(productsTable.reviewCount))
    .limit(8);

  const result = rows.map((p) => ({
    ...p,
    price: Number(p.price),
    originalPrice: p.originalPrice != null ? Number(p.originalPrice) : null,
    rating: p.rating != null ? Number(p.rating) : null,
    images: p.imageUrl ? [p.imageUrl] : [],
    createdAt: p.createdAt.toISOString(),
  }));

  res.json(result);
});

router.get("/products/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid product id" });
    return;
  }

  const [row] = await db
    .select({
      id: productsTable.id,
      name: productsTable.name,
      slug: productsTable.slug,
      description: productsTable.description,
      price: productsTable.price,
      originalPrice: productsTable.originalPrice,
      stock: productsTable.stock,
      imageUrl: productsTable.imageUrl,
      categoryId: productsTable.categoryId,
      categoryName: categoriesTable.name,
      rating: productsTable.rating,
      reviewCount: productsTable.reviewCount,
      featured: productsTable.featured,
      createdAt: productsTable.createdAt,
    })
    .from(productsTable)
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .where(eq(productsTable.id, id));

  if (!row) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  res.json({
    ...row,
    price: Number(row.price),
    originalPrice: row.originalPrice != null ? Number(row.originalPrice) : null,
    rating: row.rating != null ? Number(row.rating) : null,
    images: row.imageUrl ? [row.imageUrl] : [],
    createdAt: row.createdAt.toISOString(),
  });
});

export default router;
