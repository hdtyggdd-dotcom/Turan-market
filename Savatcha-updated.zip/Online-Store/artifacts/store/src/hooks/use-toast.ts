import { toast as sonnerToast } from "sonner"

type ToastProps = {
  title?: string;
  description?: string;
  variant?: "default" | "destructive";
  action?: {
    label: string;
    onClick: () => void;
  };
}

export const useToast = () => {
  return {
    toast: ({ title, description, variant, action }: ToastProps) => {
      if (variant === "destructive") {
        sonnerToast.error(title, { description, action })
      } else {
        sonnerToast.success(title, { description, action })
      }
    }
  }
}

export const toast = sonnerToast;
