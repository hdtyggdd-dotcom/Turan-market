import { Link, useLocation } from "wouter"
import { useGetCart } from "@workspace/api-client-react"
import { ShoppingBag, Search, Menu, Package, User, Megaphone, Truck } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

const navItems = [
  { href: "/products", label: "Qidiruv", icon: Search },
  { href: "/profile", label: "Profil", icon: User },
  { href: "/create-ad", label: "E'lon", icon: Megaphone },
  { href: "/cargo", label: "Yuk", icon: Truck },
  { href: "/orders", label: "Buyurtmalar", icon: Package },
  { href: "/cart", label: "Savat", icon: ShoppingBag },
]

export function Navbar() {
  const [location, setLocation] = useLocation()
  const { data: cart } = useGetCart()

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b bg-background/90 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setLocation("/products")}>
              <Menu className="h-5 w-5" />
            </Button>
            <Link href="/" className="flex items-center gap-2">
              <div className="h-9 w-9 rounded-xl bg-primary flex items-center justify-center text-primary-foreground shadow-sm">
                <ShoppingBag className="h-5 w-5" />
              </div>
              <span className="font-serif text-xl font-semibold tracking-tight">Savatcha</span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-5">
            <Link href="/" className="text-sm font-medium text-muted-foreground hover:text-foreground">Bosh sahifa</Link>
            <Link href="/products" className="text-sm font-medium text-muted-foreground hover:text-foreground">Mahsulotlar</Link>
            <Link href="/products?special=promo" className="text-sm font-medium text-muted-foreground hover:text-foreground">Aksiya</Link>
            <Link href="/products?special=damaged" className="text-sm font-medium text-muted-foreground hover:text-foreground">Shikastlangan</Link>
            <Link href="/cargo" className="text-sm font-medium text-muted-foreground hover:text-foreground">Yuk qo'shish</Link>
          </nav>

          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" className="hidden sm:flex" onClick={() => setLocation('/products')}>
              <Search className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="hidden sm:flex" onClick={() => setLocation('/profile')}>
              <User className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="relative" onClick={() => setLocation('/cart')}>
              <ShoppingBag className="h-5 w-5" />
              {cart && cart.itemCount > 0 && (
                <Badge variant="default" className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-[10px]">
                  {cart.itemCount}
                </Badge>
              )}
            </Button>
          </div>
        </div>
      </header>

      <nav className="md:hidden fixed bottom-0 inset-x-0 z-50 border-t bg-background/95 backdrop-blur-md safe-area-pb">
        <div className="grid grid-cols-6 h-16">
          {navItems.map(({ href, label, icon: Icon }) => {
            const active = location === href || (href === "/products" && location.startsWith("/products"))
            return (
              <Link key={href} href={href} className={`flex min-w-0 flex-col items-center justify-center gap-0.5 text-[10px] ${active ? "text-primary font-semibold" : "text-muted-foreground"}`}>
                <Icon className="h-4 w-4" />
                <span className="truncate max-w-full px-0.5">{label}</span>
                {href === "/cart" && cart && cart.itemCount > 0 ? (
                  <span className="absolute bottom-9 ml-5 min-w-4 h-4 rounded-full bg-primary px-1 text-[9px] text-primary-foreground flex items-center justify-center">{cart.itemCount}</span>
                ) : null}
              </Link>
            )
          })}
        </div>
      </nav>
    </>
  )
}
