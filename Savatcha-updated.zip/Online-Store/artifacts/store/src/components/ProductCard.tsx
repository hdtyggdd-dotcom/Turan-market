import { Link } from "wouter"
import { ShoppingBag, Star, ArrowRight } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { formatCurrency } from "@/lib/utils"
import type { Product } from "@workspace/api-client-react"
import { Button } from "@/components/ui/button"

export function ProductCard({ product }: { product: Product }) {
  const discount = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) 
    : 0;

  return (
    <div className="group flex flex-col h-full rounded-2xl overflow-hidden bg-card border border-border shadow-sm hover:shadow-md transition-all duration-300">
      <div className="relative aspect-[4/5] bg-muted overflow-hidden">
        {product.imageUrl ? (
          <img 
            src={product.imageUrl} 
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-secondary/50 text-muted-foreground">
            <ShoppingBag className="w-12 h-12 opacity-20" />
          </div>
        )}
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {product.featured && (
            <Badge className="bg-accent text-accent-foreground border-none font-medium px-2 py-0.5">Featured</Badge>
          )}
          {discount > 0 && (
            <Badge variant="destructive" className="border-none font-medium px-2 py-0.5">
              -{discount}%
            </Badge>
          )}
          {product.stock === 0 && (
            <Badge variant="secondary" className="border-none font-medium px-2 py-0.5 opacity-90 backdrop-blur-sm">
              Out of stock
            </Badge>
          )}
        </div>
        
        {/* Hover Action */}
        <div className="absolute inset-x-0 bottom-0 p-4 opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
          <Button asChild className="w-full rounded-full shadow-lg" variant="default">
            <Link href={`/products/${product.id}`}>
              View Product <ArrowRight className="w-4 h-4 ml-2" />
            </Link>
          </Button>
        </div>
      </div>
      
      <div className="p-5 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{product.categoryName}</p>
          {product.rating && (
            <div className="flex items-center text-xs font-medium text-amber-500 bg-amber-500/10 px-1.5 py-0.5 rounded">
              <Star className="w-3 h-3 fill-current mr-1" />
              {product.rating.toFixed(1)}
            </div>
          )}
        </div>
        
        <h3 className="font-serif text-lg font-medium text-foreground mb-2 line-clamp-2">
          <Link href={`/products/${product.id}`} className="hover:text-primary transition-colors">
            {product.name}
          </Link>
        </h3>
        
        <div className="mt-auto pt-4 flex items-baseline gap-2">
          <span className="text-lg font-semibold text-foreground">{formatCurrency(product.price)}</span>
          {product.originalPrice && (
            <span className="text-sm text-muted-foreground line-through decoration-muted-foreground/50">
              {formatCurrency(product.originalPrice)}
            </span>
          )}
        </div>
      </div>
    </div>
  )
}

export function ProductCardSkeleton() {
  return (
    <div className="flex flex-col h-full rounded-2xl overflow-hidden bg-card border border-border shadow-sm">
      <div className="aspect-[4/5] bg-muted animate-pulse" />
      <div className="p-5 flex flex-col flex-grow gap-3">
        <div className="h-3 w-1/3 bg-muted rounded animate-pulse" />
        <div className="h-5 w-full bg-muted rounded animate-pulse" />
        <div className="h-5 w-2/3 bg-muted rounded animate-pulse" />
        <div className="mt-auto pt-4 flex items-center gap-2">
          <div className="h-6 w-1/4 bg-muted rounded animate-pulse" />
        </div>
      </div>
    </div>
  )
}
