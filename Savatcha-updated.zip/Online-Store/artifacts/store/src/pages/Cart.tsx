import { useState } from "react"
import { Link } from "wouter"
import { 
  useGetCart, 
  useUpdateCartItem, 
  useRemoveFromCart, 
  useClearCart,
  getGetCartQueryKey
} from "@workspace/api-client-react"
import { useQueryClient } from "@tanstack/react-query"
import { Trash2, Minus, Plus, ShoppingBag, ArrowRight, ShieldCheck } from "lucide-react"
import { Button } from "@/components/ui/button"
import { MainLayout } from "@/components/layout/MainLayout"
import { formatCurrency } from "@/lib/utils"

export default function Cart() {
  const queryClient = useQueryClient()
  const { data: cart, isLoading } = useGetCart()
  
  const updateItemMutation = useUpdateCartItem()
  const removeItemMutation = useRemoveFromCart()
  const clearCartMutation = useClearCart()
  
  const handleUpdateQuantity = (productId: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    
    updateItemMutation.mutate({
      productId,
      data: { quantity: newQuantity }
    }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() })
    })
  }

  const handleRemoveItem = (productId: number) => {
    removeItemMutation.mutate({
      productId
    }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() })
    })
  }

  const handleClearCart = () => {
    clearCartMutation.mutate(undefined, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() })
    })
  }

  if (isLoading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-16">
          <div className="h-10 w-48 bg-muted animate-pulse rounded mb-8" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2 space-y-6">
              {[1, 2].map(i => (
                <div key={i} className="flex gap-4 p-4 border border-border rounded-2xl">
                  <div className="w-24 h-24 bg-muted animate-pulse rounded-xl" />
                  <div className="flex-1 space-y-3">
                    <div className="h-5 w-1/2 bg-muted animate-pulse rounded" />
                    <div className="h-4 w-1/4 bg-muted animate-pulse rounded" />
                    <div className="h-8 w-32 bg-muted animate-pulse rounded-full" />
                  </div>
                </div>
              ))}
            </div>
            <div className="h-64 w-full bg-muted animate-pulse rounded-2xl" />
          </div>
        </div>
      </MainLayout>
    )
  }

  const isEmpty = !cart || cart.items.length === 0;

  return (
    <MainLayout>
      <div className="bg-secondary/30 border-b border-border">
        <div className="container mx-auto px-4 py-8 md:py-12">
          <h1 className="font-serif text-3xl md:text-5xl font-bold text-foreground">Your Cart</h1>
          {!isEmpty && (
            <p className="text-muted-foreground text-lg mt-2">
              {cart.itemCount} item{cart.itemCount !== 1 ? 's' : ''} in your cart.
            </p>
          )}
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        {isEmpty ? (
          <div className="flex flex-col items-center justify-center py-20 text-center bg-card rounded-3xl border border-border border-dashed max-w-3xl mx-auto shadow-sm">
            <div className="w-24 h-24 bg-secondary rounded-full flex items-center justify-center mb-6 text-muted-foreground">
              <ShoppingBag className="w-10 h-10" />
            </div>
            <h2 className="font-serif text-3xl font-bold mb-3">Your cart is empty</h2>
            <p className="text-muted-foreground text-lg mb-8 max-w-md leading-relaxed">
              Looks like you haven't added anything yet. Discover our latest products and find something you love.
            </p>
            <Button asChild size="lg" className="rounded-full px-8 h-14 text-base shadow-lg shadow-primary/20">
              <Link href="/products">Continue Shopping</Link>
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            
            {/* Cart Items List */}
            <div className="lg:col-span-7 xl:col-span-8 flex flex-col gap-6">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium text-lg">Cart Items</h3>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={handleClearCart}
                  className="text-muted-foreground hover:text-destructive"
                  disabled={clearCartMutation.isPending}
                >
                  <Trash2 className="w-4 h-4 mr-2" /> Clear cart
                </Button>
              </div>

              {cart.items.map(item => (
                <div key={item.productId} className="flex flex-col sm:flex-row gap-6 p-4 md:p-6 bg-card border border-border rounded-2xl shadow-sm transition-all hover:shadow-md">
                  
                  <Link href={`/products/${item.productId}`} className="w-full sm:w-32 h-32 flex-shrink-0 bg-muted rounded-xl border border-border overflow-hidden block">
                    {item.imageUrl ? (
                      <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover transition-transform hover:scale-105" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <ShoppingBag className="w-8 h-8 opacity-20" />
                      </div>
                    )}
                  </Link>
                  
                  <div className="flex-1 flex flex-col justify-between py-1">
                    <div className="flex justify-between items-start gap-4">
                      <div>
                        <h4 className="font-serif text-xl font-bold text-foreground mb-1 leading-tight line-clamp-2">
                          <Link href={`/products/${item.productId}`} className="hover:text-primary transition-colors">
                            {item.name}
                          </Link>
                        </h4>
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-lg">{formatCurrency(item.price)}</span>
                          {item.originalPrice && (
                            <span className="text-sm text-muted-foreground line-through">{formatCurrency(item.originalPrice)}</span>
                          )}
                        </div>
                      </div>
                      
                      <button 
                        onClick={() => handleRemoveItem(item.productId)}
                        className="text-muted-foreground hover:text-destructive p-2 rounded-full hover:bg-destructive/10 transition-colors flex-shrink-0"
                        title="Remove item"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                    
                    <div className="flex justify-between items-end mt-4">
                      <div className="flex items-center bg-secondary rounded-full h-10 p-1 w-32">
                        <button 
                          className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-background transition-colors disabled:opacity-50"
                          onClick={() => handleUpdateQuantity(item.productId, item.quantity - 1)}
                          disabled={item.quantity <= 1 || updateItemMutation.isPending}
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="flex-1 text-center font-bold text-sm">{item.quantity}</span>
                        <button 
                          className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-background transition-colors disabled:opacity-50"
                          onClick={() => handleUpdateQuantity(item.productId, item.quantity + 1)}
                          disabled={updateItemMutation.isPending}
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                      
                      <div className="text-right">
                        <span className="text-sm text-muted-foreground mr-2">Subtotal</span>
                        <span className="font-bold text-lg">{formatCurrency(item.subtotal || (item.price * item.quantity))}</span>
                      </div>
                    </div>
                  </div>
                  
                </div>
              ))}
            </div>
            
            {/* Order Summary */}
            <div className="lg:col-span-5 xl:col-span-4 sticky top-24">
              <div className="bg-card border border-border rounded-3xl p-6 md:p-8 shadow-sm">
                <h3 className="font-serif text-2xl font-bold mb-6">Order Summary</h3>
                
                <div className="space-y-4 mb-6">
                  <div className="flex justify-between text-muted-foreground">
                    <span>Subtotal ({cart.itemCount} items)</span>
                    <span className="font-medium text-foreground">{formatCurrency(cart.subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>Shipping</span>
                    <span>Free</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>Taxes</span>
                    <span>Calculated at checkout</span>
                  </div>
                </div>
                
                <div className="border-t border-border pt-6 mb-8">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-xl">Total</span>
                    <span className="font-bold text-3xl text-primary">{formatCurrency(cart.total)}</span>
                  </div>
                </div>
                
                <Button asChild size="lg" className="w-full h-14 rounded-full text-base font-semibold shadow-lg shadow-primary/20">
                  <Link href="/checkout">
                    Proceed to Checkout <ArrowRight className="w-5 h-5 ml-2" />
                  </Link>
                </Button>
                
                <div className="mt-6 flex justify-center items-center gap-2 text-sm text-muted-foreground">
                  <ShieldCheck className="w-4 h-4" /> Secure SSL Checkout
                </div>
              </div>
            </div>
            
          </div>
        )}
      </div>
    </MainLayout>
  )
}
