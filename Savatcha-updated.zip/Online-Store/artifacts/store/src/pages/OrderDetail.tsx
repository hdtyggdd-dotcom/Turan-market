import { useParams, Link } from "wouter"
import { useGetOrder, OrderStatus, getGetOrderQueryKey } from "@workspace/api-client-react"
import { ChevronLeft, Package, Clock, Truck, CheckCircle2, XCircle, MapPin, Receipt, ShoppingBag } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MainLayout } from "@/components/layout/MainLayout"
import { formatCurrency } from "@/lib/utils"

export default function OrderDetail() {
  const { id } = useParams<{ id: string }>()
  const orderId = parseInt(id)
  
  const { data: order, isLoading, isError } = useGetOrder(orderId, {
    query: { enabled: !isNaN(orderId), queryKey: getGetOrderQueryKey(orderId) }
  })

  if (isLoading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-12 max-w-4xl">
          <div className="h-8 w-64 bg-muted animate-pulse rounded mb-8" />
          <div className="h-40 w-full bg-card rounded-2xl animate-pulse mb-8 border border-border" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2 h-96 bg-card rounded-2xl animate-pulse border border-border" />
            <div className="h-96 bg-card rounded-2xl animate-pulse border border-border" />
          </div>
        </div>
      </MainLayout>
    )
  }

  if (isError || !order) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-32 text-center flex flex-col items-center">
          <h1 className="font-serif text-4xl font-bold mb-4 text-foreground">Order Not Found</h1>
          <p className="text-muted-foreground mb-8 text-lg">We couldn't find an order with this ID.</p>
          <Button asChild size="lg" className="rounded-full">
            <Link href="/orders">Back to Orders</Link>
          </Button>
        </div>
      </MainLayout>
    )
  }

  const getStatusDisplay = (status: OrderStatus) => {
    switch (status) {
      case OrderStatus.pending:
        return { color: "text-amber-600 bg-amber-50 border-amber-200", icon: Clock, text: "Pending" }
      case OrderStatus.processing:
        return { color: "text-blue-600 bg-blue-50 border-blue-200", icon: Package, text: "Processing" }
      case OrderStatus.shipped:
        return { color: "text-purple-600 bg-purple-50 border-purple-200", icon: Truck, text: "Shipped" }
      case OrderStatus.delivered:
        return { color: "text-emerald-600 bg-emerald-50 border-emerald-200", icon: CheckCircle2, text: "Delivered" }
      case OrderStatus.cancelled:
        return { color: "text-destructive bg-destructive/10 border-destructive/20", icon: XCircle, text: "Cancelled" }
      default:
        return { color: "text-muted-foreground bg-secondary border-border", icon: Package, text: status }
    }
  }

  const statusDisplay = getStatusDisplay(order.status)
  const StatusIcon = statusDisplay.icon

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  return (
    <MainLayout>
      <div className="bg-secondary/30 border-b border-border">
        <div className="container mx-auto px-4 py-6 max-w-5xl">
          <Link href="/orders" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground transition-colors mb-6">
            <ChevronLeft className="w-4 h-4 mr-1" />
            Back to Orders
          </Link>
          
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <h1 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-2">
                Order #{order.id.toString().padStart(6, '0')}
              </h1>
              <p className="text-muted-foreground">Placed on {formatDate(order.createdAt)}</p>
            </div>
            
            <div className={`inline-flex items-center px-4 py-2 rounded-full border ${statusDisplay.color}`}>
              <StatusIcon className="w-5 h-5 mr-2" />
              <span className="font-bold">{statusDisplay.text}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 max-w-5xl">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          
          {/* Main content - Items list */}
          <div className="lg:col-span-2">
            <div className="bg-card border border-border rounded-3xl overflow-hidden shadow-sm">
              <div className="p-6 md:p-8 border-b border-border">
                <h2 className="font-serif text-2xl font-bold mb-2">Items Ordered</h2>
                <p className="text-muted-foreground">{order.items.reduce((acc, item) => acc + item.quantity, 0)} items total</p>
              </div>
              
              <div className="divide-y divide-border">
                {order.items.map((item, idx) => (
                  <div key={idx} className="p-6 md:p-8 flex flex-col sm:flex-row gap-6">
                    <Link href={`/products/${item.productId}`} className="w-full sm:w-28 h-28 bg-muted rounded-xl border border-border overflow-hidden shrink-0 block">
                      {item.imageUrl ? (
                        <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover transition-transform hover:scale-105" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <ShoppingBag className="w-8 h-8 opacity-20" />
                        </div>
                      )}
                    </Link>
                    
                    <div className="flex-1 flex flex-col justify-between">
                      <div className="flex justify-between items-start gap-4">
                        <div>
                          <h4 className="font-serif text-xl font-bold text-foreground mb-1 leading-tight line-clamp-2 hover:text-primary transition-colors">
                            <Link href={`/products/${item.productId}`}>{item.name}</Link>
                          </h4>
                          <p className="text-muted-foreground">Qty: {item.quantity}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-lg">{formatCurrency(item.price)}</p>
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-end mt-4 pt-4 border-t border-border border-dashed">
                        <span className="text-sm text-muted-foreground font-medium">Subtotal</span>
                        <span className="font-bold">{formatCurrency(item.price * item.quantity)}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          {/* Sidebar - Summary & Details */}
          <div className="space-y-8">
            {/* Order Summary */}
            <div className="bg-card border border-border rounded-3xl p-6 shadow-sm">
              <div className="flex items-center gap-3 mb-6 pb-6 border-b border-border">
                <Receipt className="w-5 h-5 text-primary" />
                <h3 className="font-serif text-xl font-bold">Summary</h3>
              </div>
              
              <div className="space-y-4 mb-6">
                <div className="flex justify-between text-muted-foreground">
                  <span>Subtotal</span>
                  <span className="font-medium text-foreground">{formatCurrency(order.total)}</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Shipping</span>
                  <span>Free</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Taxes</span>
                  <span>$0.00</span>
                </div>
              </div>
              
              <div className="border-t border-border pt-6">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-lg">Total</span>
                  <span className="font-bold text-3xl text-primary">{formatCurrency(order.total)}</span>
                </div>
              </div>
            </div>
            
            {/* Customer Details */}
            <div className="bg-card border border-border rounded-3xl p-6 shadow-sm">
              <div className="flex items-center gap-3 mb-6 pb-6 border-b border-border">
                <MapPin className="w-5 h-5 text-primary" />
                <h3 className="font-serif text-xl font-bold">Delivery Info</h3>
              </div>
              
              <div className="space-y-6">
                <div>
                  <h4 className="text-xs uppercase tracking-wider font-bold text-muted-foreground mb-2">Customer</h4>
                  <p className="font-medium">{order.customerName}</p>
                  <p className="text-muted-foreground text-sm">{order.customerEmail}</p>
                </div>
                
                <div>
                  <h4 className="text-xs uppercase tracking-wider font-bold text-muted-foreground mb-2">Shipping Address</h4>
                  <p className="whitespace-pre-line text-sm leading-relaxed">{order.shippingAddress}</p>
                </div>
              </div>
            </div>
            
            <Button asChild variant="outline" className="w-full rounded-full h-12">
              <Link href="/products">Continue Shopping</Link>
            </Button>
          </div>
          
        </div>
      </div>
    </MainLayout>
  )
}
