import { useState } from "react"
import { Link } from "wouter"
import { useGetStoreSummary, useGetFeaturedProducts, useListCategories } from "@workspace/api-client-react"
import { ArrowRight, TrendingUp, ShieldCheck, Truck, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ProductCard, ProductCardSkeleton } from "@/components/ProductCard"
import { MainLayout } from "@/components/layout/MainLayout"

export default function Home() {
  const { data: summary, isLoading: isSummaryLoading } = useGetStoreSummary()
  const { data: featuredProducts, isLoading: isFeaturedLoading } = useGetFeaturedProducts()
  const { data: categories, isLoading: isCategoriesLoading } = useListCategories()

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-accent/30 py-20 md:py-32">
        <div className="absolute inset-0 z-0">
          <div className="absolute -top-[20%] -right-[10%] w-[50%] h-[80%] rounded-full bg-primary/10 blur-3xl filter opacity-70 animate-pulse" />
          <div className="absolute -bottom-[20%] -left-[10%] w-[40%] h-[60%] rounded-full bg-chart-4/10 blur-3xl filter opacity-70" />
        </div>
        
        <div className="container relative z-10 mx-auto px-4 flex flex-col items-center text-center">
          <div className="inline-flex items-center rounded-full border border-primary/20 bg-primary/5 px-3 py-1 text-sm text-primary mb-8 backdrop-blur-sm">
            <TrendingUp className="mr-2 h-4 w-4" />
            <span className="font-medium">Discover our new spring collection</span>
          </div>
          
          <h1 className="font-serif text-5xl md:text-7xl font-bold tracking-tight text-foreground max-w-4xl mb-6">
            Curated essentials for the modern lifestyle.
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mb-10 leading-relaxed">
            Elevate your everyday with thoughtfully designed products that blend beautiful form with effortless function.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
            <Button size="lg" asChild className="rounded-full px-8 text-base h-14 shadow-lg shadow-primary/20">
              <Link href="/products">
                Shop the Collection
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild className="rounded-full px-8 text-base h-14 bg-background/50 backdrop-blur-md">
              <Link href="/products?sort=newest">
                View New Arrivals
              </Link>
            </Button>
          </div>
          
          {/* Stats */}
          {!isSummaryLoading && summary && (
            <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 pt-8 border-t border-border/50 w-full max-w-4xl">
              <div className="flex flex-col items-center">
                <span className="text-3xl font-bold font-serif text-foreground">{summary.totalProducts}</span>
                <span className="text-sm text-muted-foreground uppercase tracking-wider font-medium mt-1">Products</span>
              </div>
              <div className="flex flex-col items-center">
                <span className="text-3xl font-bold font-serif text-foreground">{summary.totalCategories}</span>
                <span className="text-sm text-muted-foreground uppercase tracking-wider font-medium mt-1">Categories</span>
              </div>
              <div className="flex flex-col items-center">
                <span className="text-3xl font-bold font-serif text-foreground">{summary.totalOrders}+</span>
                <span className="text-sm text-muted-foreground uppercase tracking-wider font-medium mt-1">Orders</span>
              </div>
              <div className="flex flex-col items-center">
                <span className="text-3xl font-bold font-serif text-foreground">4.9/5</span>
                <span className="text-sm text-muted-foreground uppercase tracking-wider font-medium mt-1">Rating</span>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-3">Featured Highlights</h2>
              <p className="text-muted-foreground text-lg">Hand-picked selections our customers love most.</p>
            </div>
            <Button variant="ghost" asChild className="hidden md:flex">
              <Link href="/products?featured=true">
                View all featured <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {isFeaturedLoading ? (
              Array(4).fill(0).map((_, i) => <ProductCardSkeleton key={i} />)
            ) : featuredProducts?.slice(0, 4).map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          
          <Button variant="outline" asChild className="w-full mt-8 md:hidden rounded-full">
            <Link href="/products?featured=true">
              View all featured
            </Link>
          </Button>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-4">Shop by Category</h2>
            <p className="text-muted-foreground text-lg">Find exactly what you're looking for by browsing our curated collections.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Link href="/products?special=promo" className="group relative rounded-2xl overflow-hidden bg-primary/10 border border-primary/20 min-h-[220px] p-8 flex flex-col justify-end">
              <div className="absolute top-6 right-6 h-14 w-14 rounded-2xl bg-primary text-primary-foreground flex items-center justify-center text-xl font-bold">%</div>
              <p className="text-sm font-semibold text-primary mb-2">MAXSUS</p>
              <h3 className="text-2xl font-serif font-bold">Aksiya</h3>
              <p className="text-muted-foreground mt-2">Chegirmadagi mahsulotlarni ko‘ring.</p>
            </Link>
            <Link href="/products?special=damaged" className="group relative rounded-2xl overflow-hidden bg-destructive/5 border border-destructive/20 min-h-[220px] p-8 flex flex-col justify-end">
              <div className="absolute top-6 right-6 h-14 w-14 rounded-2xl bg-destructive/10 text-destructive flex items-center justify-center">!</div>
              <p className="text-sm font-semibold text-destructive mb-2">ALOIDA</p>
              <h3 className="text-2xl font-serif font-bold">Shikastlangan tovarlar</h3>
              <p className="text-muted-foreground mt-2">Holati ko‘rsatilgan mahsulotlar.</p>
            </Link>
            {isCategoriesLoading ? (
              Array(3).fill(0).map((_, i) => (
                <div key={i} className="aspect-[4/3] rounded-2xl bg-muted animate-pulse" />
              ))
            ) : categories?.slice(0, 6).map((category, i) => (
              <Link 
                key={category.id} 
                href={`/products?categoryId=${category.id}`}
                className={`group relative rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 ${
                  i === 0 ? 'md:col-span-2 aspect-[16/9] md:aspect-auto' : 'aspect-[4/3]'
                }`}
              >
                {category.imageUrl ? (
                  <img 
                    src={category.imageUrl} 
                    alt={category.name} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                ) : (
                  <div className="w-full h-full bg-primary/10 flex items-center justify-center">
                    <span className="text-4xl font-serif text-primary/30 opacity-50">{category.name[0]}</span>
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col justify-end p-8">
                  <h3 className="text-2xl font-serif font-bold text-white mb-2">{category.name}</h3>
                  <div className="flex items-center text-white/80 group-hover:text-white transition-colors">
                    <span className="text-sm font-medium">{category.productCount || 0} Products</span>
                    <ArrowRight className="w-4 h-4 ml-2 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Value Props */}
      <section className="py-20 bg-background border-t border-border">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10 text-center">
            <div className="flex flex-col items-center">
              <div className="h-16 w-16 rounded-2xl bg-accent/50 flex items-center justify-center text-accent-foreground mb-6">
                <Truck className="h-8 w-8" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-3">Free Express Shipping</h3>
              <p className="text-muted-foreground leading-relaxed">Enjoy complimentary express delivery on all orders over $100. Track your package right to your door.</p>
            </div>
            
            <div className="flex flex-col items-center">
              <div className="h-16 w-16 rounded-2xl bg-chart-2/20 flex items-center justify-center text-chart-2 mb-6">
                <ShieldCheck className="h-8 w-8" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-3">Secure Payments</h3>
              <p className="text-muted-foreground leading-relaxed">Your data is protected with military-grade encryption. We support all major credit cards and digital wallets.</p>
            </div>
            
            <div className="flex flex-col items-center">
              <div className="h-16 w-16 rounded-2xl bg-chart-4/20 flex items-center justify-center text-chart-4 mb-6">
                <RefreshCw className="h-8 w-8" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-3">Easy Returns</h3>
              <p className="text-muted-foreground leading-relaxed">Not totally satisfied? Return your unused items within 30 days for a full refund, no questions asked.</p>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  )
}
