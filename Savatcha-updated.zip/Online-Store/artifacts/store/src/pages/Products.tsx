import { useState, useMemo } from "react"
import { useLocation } from "wouter"
import { 
  useListProducts, 
  useListCategories,
  ListProductsSort,
  getListProductsQueryKey
} from "@workspace/api-client-react"
import { Filter, SlidersHorizontal, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ProductCard, ProductCardSkeleton } from "@/components/ProductCard"
import { MainLayout } from "@/components/layout/MainLayout"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"

export default function Products() {
  const [location] = useLocation()
  const searchParams = new URLSearchParams(window.location.search)
  const special = searchParams.get("special")
  
  const [categoryId, setCategoryId] = useState<number | null>(
    searchParams.get("categoryId") ? Number(searchParams.get("categoryId")) : null
  )
  const [search, setSearch] = useState(searchParams.get("search") || "")
  const [searchQuery, setSearchQuery] = useState(search) // Debounced version for API
  const [sort, setSort] = useState<ListProductsSort>(
    (searchParams.get("sort") as ListProductsSort) || ListProductsSort.newest
  )
  
  const [isMobileFiltersOpen, setIsMobileFiltersOpen] = useState(false)

  const { data: categories, isLoading: isCategoriesLoading } = useListCategories()
  
  const listParams = {
    categoryId: categoryId,
    search: searchQuery || null,
    sort: sort
  };
  const { data: products, isLoading: isProductsLoading } = useListProducts(listParams, { 
    query: { queryKey: getListProductsQueryKey(listParams) } 
  })
  const visibleProducts = products?.filter((product) => {
    if (special === "promo") return product.originalPrice != null && product.originalPrice > product.price
    if (special === "damaged") return (product.categoryName || "").toLowerCase().includes("shikast")
    return true
  })

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setSearchQuery(search)
  }

  const clearFilters = () => {
    setCategoryId(null)
    setSearch("")
    setSearchQuery("")
    setSort(ListProductsSort.newest)
  }

  const hasActiveFilters = categoryId !== null || searchQuery !== "" || sort !== ListProductsSort.newest

  return (
    <MainLayout>
      <div className="bg-secondary/30 border-b border-border py-8 md:py-12">
        <div className="container mx-auto px-4">
          <h1 className="font-serif text-3xl md:text-5xl font-bold text-foreground mb-4">
            {special === "promo" ? "Aksiya" : special === "damaged" ? "Shikastlangan tovarlar" : categoryId ? categories?.find(c => c.id === categoryId)?.name || "Products" : "All Products"}
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl">
            {special === "promo" ? "Chegirmadagi mahsulotlar." : special === "damaged" ? "Shikastlangan holatdagi mahsulotlar alohida ko‘rsatiladi." : categoryId ? categories?.find(c => c.id === categoryId)?.description || "Explore our selection of premium items." : "Explore our entire collection of premium lifestyle essentials."}
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          
          {/* Mobile Filter Toggle */}
          <div className="lg:hidden flex justify-between items-center pb-4 border-b border-border">
            <Button variant="outline" onClick={() => setIsMobileFiltersOpen(!isMobileFiltersOpen)}>
              <Filter className="w-4 h-4 mr-2" />
              Filters
            </Button>
            <div className="w-40">
              <Select value={sort || ""} onValueChange={(val) => setSort(val as ListProductsSort)}>
                <SelectTrigger>
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={ListProductsSort.newest}>Newest Arrivals</SelectItem>
                  <SelectItem value={ListProductsSort.popular}>Most Popular</SelectItem>
                  <SelectItem value={ListProductsSort.price_asc}>Price: Low to High</SelectItem>
                  <SelectItem value={ListProductsSort.price_desc}>Price: High to Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Sidebar Filters */}
          <div className={`lg:w-64 flex-shrink-0 ${isMobileFiltersOpen ? 'block' : 'hidden lg:block'}`}>
            <div className="sticky top-24 space-y-8">
              
              {/* Search */}
              <div>
                <h3 className="font-serif font-medium text-lg mb-4 flex items-center gap-2">
                  <SearchIcon className="w-5 h-5 text-primary" /> Search
                </h3>
                <form onSubmit={handleSearch} className="flex gap-2">
                  <Input 
                    placeholder="Search products..." 
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                  <Button type="submit" size="icon" variant="secondary">
                    <SearchIcon className="w-4 h-4" />
                  </Button>
                </form>
              </div>

              {/* Categories */}
              <div>
                <h3 className="font-serif font-medium text-lg mb-4 flex items-center gap-2">
                  <Filter className="w-5 h-5 text-primary" /> Categories
                </h3>
                {isCategoriesLoading ? (
                  <div className="space-y-2">
                    {[1, 2, 3, 4, 5].map(i => <div key={i} className="h-6 bg-muted rounded animate-pulse" />)}
                  </div>
                ) : (
                  <div className="space-y-2">
                    <button
                      onClick={() => setCategoryId(null)}
                      className={`block w-full text-left px-3 py-2 rounded-md transition-colors text-sm ${
                        categoryId === null 
                          ? 'bg-primary/10 text-primary font-medium' 
                          : 'hover:bg-secondary text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      All Categories
                    </button>
                    {categories?.map(category => (
                      <button
                        key={category.id}
                        onClick={() => setCategoryId(category.id)}
                        className={`flex w-full items-center justify-between text-left px-3 py-2 rounded-md transition-colors text-sm ${
                          categoryId === category.id 
                            ? 'bg-primary/10 text-primary font-medium' 
                            : 'hover:bg-secondary text-muted-foreground hover:text-foreground'
                        }`}
                      >
                        <span>{category.name}</span>
                        <span className="text-xs bg-background rounded-full px-2 py-0.5 border border-border">
                          {category.productCount}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Active Filters */}
              {hasActiveFilters && (
                <div className="pt-4 border-t border-border">
                  <Button variant="outline" className="w-full text-destructive hover:text-destructive-foreground hover:bg-destructive border-destructive/20" onClick={clearFilters}>
                    <X className="w-4 h-4 mr-2" />
                    Clear All Filters
                  </Button>
                </div>
              )}
            </div>
          </div>

          {/* Product Grid */}
          <div className="flex-1">
            <div className="hidden lg:flex justify-between items-center mb-6 pb-6 border-b border-border">
              <p className="text-muted-foreground">
                Showing <span className="font-medium text-foreground">{visibleProducts?.length || 0}</span> products
              </p>
              
              <div className="flex items-center gap-4">
                <span className="text-sm font-medium text-muted-foreground">Sort by:</span>
                <div className="w-48">
                  <Select value={sort || ""} onValueChange={(val) => setSort(val as ListProductsSort)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={ListProductsSort.newest}>Newest Arrivals</SelectItem>
                      <SelectItem value={ListProductsSort.popular}>Most Popular</SelectItem>
                      <SelectItem value={ListProductsSort.price_asc}>Price: Low to High</SelectItem>
                      <SelectItem value={ListProductsSort.price_desc}>Price: High to Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {isProductsLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {Array(9).fill(0).map((_, i) => <ProductCardSkeleton key={i} />)}
              </div>
            ) : visibleProducts?.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-center bg-secondary/20 rounded-2xl border border-border border-dashed">
                <div className="w-16 h-16 bg-background rounded-full flex items-center justify-center mb-4 text-muted-foreground shadow-sm">
                  <SearchIcon className="w-8 h-8" />
                </div>
                <h3 className="font-serif text-2xl font-bold mb-2">No products found</h3>
                <p className="text-muted-foreground mb-6 max-w-md">
                  We couldn't find anything matching your current filters. Try adjusting your search or category selection.
                </p>
                <Button onClick={clearFilters}>Clear Filters</Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {visibleProducts?.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>

        </div>
      </div>
    </MainLayout>
  )
}

function SearchIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.3-4.3" />
    </svg>
  )
}
