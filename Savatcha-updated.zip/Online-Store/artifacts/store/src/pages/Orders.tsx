import { Link } from "wouter"
import { useListOrders, OrderStatus } from "@workspace/api-client-react"
import { Package, Clock, Truck, CheckCircle2, XCircle, ArrowRight, ShoppingBag } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MainLayout } from "@/components/layout/MainLayout"
import { formatCurrency } from "@/lib/utils"

export default function Orders() {
  const { data: orders, isLoading } = useListOrders()

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case OrderStatus.pending:
        return <Badge variant="secondary" className="bg-amber-100 text-amber-800 hover:bg-amber-100"><Clock className="w-3 h-3 mr-1" /> Pending</Badge>
      case OrderStatus.processing:
        return <Badge variant="secondary" className="bg-blue-100 text-blue-800 hover:bg-blue-100"><Package className="w-3 h-3 mr-1" /> Processing</Badge>
      case OrderStatus.shipped:
        return <Badge variant="secondary" className="bg-purple-100 text-purple-800 hover:bg-purple-100"><Truck className="w-3 h-3 mr-1" /> Shipped</Badge>
      case OrderStatus.delivered:
        return <Badge variant="secondary" className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100"><CheckCircle2 className="w-3 h-3 mr-1" /> Delivered</Badge>
      case OrderStatus.cancelled:
        return <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" /> Cancelled</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  return (
    <MainLayout>
      <div className="bg-secondary/30 border-b border-border">
        <div className="container mx-auto px-4 py-8 md:py-12">
          <h1 className="font-serif text-3xl md:text-5xl font-bold text-foreground">Order History</h1>
          <p className="text-muted-foreground text-lg mt-2">Track and review your past purchases.</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        {isLoading ? (
          <div className="space-y-6">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-48 bg-card border border-border rounded-2xl animate-pulse" />
            ))}
          </div>
        ) : !orders || orders.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center bg-card rounded-3xl border border-border border-dashed max-w-3xl mx-auto shadow-sm">
            <div className="w-24 h-24 bg-secondary rounded-full flex items-center justify-center mb-6 text-muted-foreground">
              <Package className="w-10 h-10" />
            </div>
            <h2 className="font-serif text-3xl font-bold mb-3">No orders yet</h2>
            <p className="text-muted-foreground text-lg mb-8 max-w-md leading-relaxed">
              When you place orders, they will appear here so you can track their status.
            </p>
            <Button asChild size="lg" className="rounded-full px-8 h-14 text-base shadow-lg shadow-primary/20">
              <Link href="/products">Start Shopping</Link>
            </Button>
          </div>
        ) : (
          <div className="space-y-6 max-w-5xl mx-auto">
            {orders.map((order) => (
              <div key={order.id} className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                {/* Header */}
                <div className="bg-secondary/40 px-6 py-4 border-b border-border flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="grid grid-cols-2 md:flex md:gap-12 gap-y-4">
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-1">Order Number</p>
                      <p className="font-mono font-medium">#{order.id.toString().padStart(6, '0')}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-1">Date Placed</p>
                      <p className="font-medium">{formatDate(order.createdAt)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-1">Total Amount</p>
                      <p className="font-bold text-primary">{formatCurrency(order.total)}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between md:justify-end md:w-auto w-full pt-4 md:pt-0 border-t border-border md:border-0">
                    <div className="mr-4">
                      {getStatusBadge(order.status)}
                    </div>
                    <Button asChild variant="outline" size="sm" className="rounded-full shrink-0">
                      <Link href={`/orders/${order.id}`}>
                        View Details <ArrowRight className="w-4 h-4 ml-1" />
                      </Link>
                    </Button>
                  </div>
                </div>
                
                {/* Content - Image preview row */}
                <div className="p-6">
                  <h4 className="text-sm font-semibold mb-4 text-muted-foreground">Items in this order</h4>
                  <div className="flex gap-4 overflow-x-auto pb-2">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="relative group shrink-0">
                        <div className="w-20 h-20 bg-muted rounded-xl border border-border overflow-hidden">
                          {item.imageUrl ? (
                            <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <ShoppingBag className="w-6 h-6 opacity-20" />
                            </div>
                          )}
                        </div>
                        <div className="absolute -top-2 -right-2 w-5 h-5 bg-foreground text-background text-[10px] font-bold rounded-full flex items-center justify-center">
                          {item.quantity}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </MainLayout>
  )
}
