import { Link } from "wouter"
import { User, Package, Megaphone, Truck, ShoppingBag } from "lucide-react"
import { Button } from "@/components/ui/button"
import { MainLayout } from "@/components/layout/MainLayout"

export default function Profile() {
  const actions = [
    { href: "/orders", label: "Mening buyurtmalarim", icon: Package },
    { href: "/create-ad", label: "E'lon joylash", icon: Megaphone },
    { href: "/cargo", label: "Yuk qo'shish", icon: Truck },
    { href: "/cart", label: "Mening savatim", icon: ShoppingBag },
  ]
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-10 md:py-16 max-w-4xl">
        <div className="rounded-3xl border bg-card p-8 md:p-10 shadow-sm">
          <div className="flex items-center gap-5 mb-8">
            <div className="h-16 w-16 rounded-2xl bg-primary/10 text-primary flex items-center justify-center">
              <User className="h-8 w-8" />
            </div>
            <div>
              <h1 className="font-serif text-3xl font-bold">Profil</h1>
              <p className="text-muted-foreground">Buyurtmalar, e'lonlar va savatni boshqaring.</p>
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {actions.map(({href,label,icon:Icon}) => (
              <Button key={href} asChild variant="outline" className="h-16 justify-start rounded-2xl text-base">
                <Link href={href}><Icon className="mr-3 h-5 w-5 text-primary" />{label}</Link>
              </Button>
            ))}
          </div>
        </div>
      </div>
    </MainLayout>
  )
}
