import { Link } from "wouter"
import { Button } from "@/components/ui/button"
import { MainLayout } from "@/components/layout/MainLayout"
import { ShoppingBag } from "lucide-react"

export default function NotFound() {
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-32 text-center flex flex-col items-center justify-center min-h-[60vh]">
        <div className="w-24 h-24 bg-secondary rounded-full flex items-center justify-center mb-6 text-muted-foreground">
          <ShoppingBag className="w-10 h-10 opacity-50" />
        </div>
        <h1 className="font-serif text-5xl font-bold mb-4 text-foreground">404</h1>
        <h2 className="font-serif text-2xl font-semibold mb-3 text-foreground">Page Not Found</h2>
        <p className="text-muted-foreground mb-8 text-lg max-w-md">
          The page you're looking for doesn't exist, has been moved, or is temporarily unavailable.
        </p>
        <Button asChild size="lg" className="rounded-full">
          <Link href="/">Return to Home</Link>
        </Button>
      </div>
    </MainLayout>
  )
}
