import { useState } from "react"
import { useLocation } from "wouter"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { 
  useGetCart, 
  useCreateOrder,
  getGetCartQueryKey,
  getListOrdersQueryKey
} from "@workspace/api-client-react"
import { useQueryClient } from "@tanstack/react-query"
import { ShieldCheck, Lock, ChevronLeft, CreditCard, ShoppingBag } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { MainLayout } from "@/components/layout/MainLayout"
import { formatCurrency } from "@/lib/utils"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import { useToast } from "@/hooks/use-toast"

const checkoutSchema = z.object({
  customerName: z.string().min(2, "Name is required").max(100),
  customerEmail: z.string().email("Invalid email address"),
  shippingAddress: z.string().min(10, "Please provide a complete shipping address"),
  cardNumber: z.string().min(15, "Invalid card number"),
  cardExpiry: z.string().regex(/^(0[1-9]|1[0-2])\/?([0-9]{2})$/, "Invalid expiry (MM/YY)"),
  cardCvc: z.string().min(3, "Invalid CVC").max(4),
})

type CheckoutFormValues = z.infer<typeof checkoutSchema>

export default function Checkout() {
  const [, setLocation] = useLocation()
  const { toast } = useToast()
  const queryClient = useQueryClient()
  
  const { data: cart, isLoading } = useGetCart()
  const createOrderMutation = useCreateOrder()
  
  const form = useForm<CheckoutFormValues>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: {
      customerName: "",
      customerEmail: "",
      shippingAddress: "",
      cardNumber: "",
      cardExpiry: "",
      cardCvc: "",
    },
  })

  const onSubmit = (data: CheckoutFormValues) => {
    createOrderMutation.mutate({
      data: {
        customerName: data.customerName,
        customerEmail: data.customerEmail,
        shippingAddress: data.shippingAddress,
      }
    }, {
      onSuccess: (order) => {
        // Clear caches
        queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() })
        queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() })
        
        toast({
          title: "Order placed successfully!",
          description: `Your order #${order.id} has been confirmed.`,
        })
        
        // Redirect to order confirmation
        setLocation(`/orders/${order.id}`)
      },
      onError: (error: any) => {
        toast({
          title: "Failed to place order",
          description: error?.message || "There was a problem processing your order.",
          variant: "destructive",
        })
      }
    })
  }

  // Redirect if cart is empty
  if (!isLoading && (!cart || cart.items.length === 0)) {
    setLocation('/cart')
    return null
  }

  return (
    <MainLayout>
      <div className="bg-secondary/30 border-b border-border">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center gap-4 text-sm font-medium text-muted-foreground mb-4">
            <button onClick={() => window.history.back()} className="flex items-center hover:text-foreground">
              <ChevronLeft className="w-4 h-4 mr-1" /> Return to Cart
            </button>
            <span>/</span>
            <span className="text-foreground font-bold">Checkout</span>
          </div>
          <h1 className="font-serif text-3xl md:text-5xl font-bold text-foreground">Secure Checkout</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start flex-col-reverse lg:flex-row">
          
          {/* Checkout Form */}
          <div className="lg:col-span-7 xl:col-span-8">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-10">
                
                {/* Contact & Shipping Info */}
                <div className="bg-card border border-border rounded-3xl p-6 md:p-8 shadow-sm">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold">1</div>
                    <h2 className="font-serif text-2xl font-bold">Contact & Shipping Info</h2>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="customerName"
                      render={({ field }) => (
                        <FormItem className="md:col-span-2">
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John Doe" {...field} className="h-12 bg-background" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="customerEmail"
                      render={({ field }) => (
                        <FormItem className="md:col-span-2">
                          <FormLabel>Email Address</FormLabel>
                          <FormControl>
                            <Input placeholder="john@example.com" type="email" {...field} className="h-12 bg-background" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="shippingAddress"
                      render={({ field }) => (
                        <FormItem className="md:col-span-2">
                          <FormLabel>Full Shipping Address</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="123 Main St, Apt 4B&#10;City, State, ZIP&#10;Country" 
                              className="min-h-[100px] bg-background resize-none"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                
                {/* Payment Info (Mock) */}
                <div className="bg-card border border-border rounded-3xl p-6 md:p-8 shadow-sm relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-bl-full pointer-events-none" />
                  
                  <div className="flex items-center justify-between mb-6 relative z-10">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold">2</div>
                      <h2 className="font-serif text-2xl font-bold">Payment Details</h2>
                    </div>
                    <div className="flex gap-2">
                      <div className="w-10 h-6 bg-muted rounded flex items-center justify-center text-[10px] font-bold">VISA</div>
                      <div className="w-10 h-6 bg-muted rounded flex items-center justify-center text-[10px] font-bold">MC</div>
                    </div>
                  </div>
                  
                  <div className="bg-secondary/30 rounded-xl p-4 mb-6 border border-border flex items-start gap-3">
                    <Lock className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <p className="text-sm text-muted-foreground">
                      This is a secure 128-bit SSL encrypted payment. Your payment details are processed safely and never stored on our servers.
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-6 relative z-10">
                    <FormField
                      control={form.control}
                      name="cardNumber"
                      render={({ field }) => (
                        <FormItem className="col-span-2">
                          <FormLabel>Card Number</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                              <Input placeholder="0000 0000 0000 0000" {...field} className="h-12 pl-11 font-mono tracking-widest bg-background" />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="cardExpiry"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Expiry Date</FormLabel>
                          <FormControl>
                            <Input placeholder="MM/YY" {...field} className="h-12 bg-background font-mono text-center" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="cardCvc"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>CVC</FormLabel>
                          <FormControl>
                            <Input placeholder="123" {...field} className="h-12 bg-background font-mono text-center" type="password" maxLength={4} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <div className="pt-4 flex justify-end">
                  <Button 
                    type="submit" 
                    size="lg" 
                    className="w-full md:w-auto px-12 h-14 rounded-full text-lg shadow-lg shadow-primary/20"
                    disabled={createOrderMutation.isPending}
                  >
                    {createOrderMutation.isPending ? "Processing Order..." : `Pay ${formatCurrency(cart?.total || 0)}`}
                  </Button>
                </div>
                
              </form>
            </Form>
          </div>
          
          {/* Order Summary Sidebar */}
          <div className="lg:col-span-5 xl:col-span-4 lg:sticky lg:top-24 mt-0 lg:mt-0 lg:order-last order-first mb-8 lg:mb-0">
            <div className="bg-card border border-border rounded-3xl p-6 md:p-8 shadow-sm">
              <h3 className="font-serif text-2xl font-bold mb-6 flex items-center justify-between">
                Your Order
                <span className="text-sm font-sans font-normal text-muted-foreground border border-border rounded-full px-2.5 py-0.5">
                  {cart?.itemCount} items
                </span>
              </h3>
              
              <div className="space-y-4 mb-6 max-h-[300px] overflow-y-auto pr-2 -mr-2">
                {cart?.items.map(item => (
                  <div key={item.productId} className="flex gap-4 items-center">
                    <div className="relative">
                      <div className="w-16 h-16 bg-muted rounded-lg border border-border overflow-hidden">
                        {item.imageUrl ? (
                          <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                        ) : (
                          <ShoppingBag className="w-6 h-6 m-auto mt-5 opacity-20" />
                        )}
                      </div>
                      <div className="absolute -top-2 -right-2 w-5 h-5 bg-foreground text-background text-[10px] font-bold rounded-full flex items-center justify-center">
                        {item.quantity}
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-medium text-foreground truncate">{item.name}</h4>
                      <p className="text-sm text-muted-foreground">{formatCurrency(item.price)}</p>
                    </div>
                    <div className="font-medium text-right">
                      {formatCurrency(item.price * item.quantity)}
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="border-t border-border pt-6 space-y-3 mb-6">
                <div className="flex justify-between text-muted-foreground text-sm">
                  <span>Subtotal</span>
                  <span className="font-medium text-foreground">{formatCurrency(cart?.subtotal || 0)}</span>
                </div>
                <div className="flex justify-between text-muted-foreground text-sm">
                  <span>Shipping</span>
                  <span className="font-medium text-emerald-600">Free</span>
                </div>
              </div>
              
              <div className="border-t border-border pt-6 mb-2">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-lg">Total</span>
                  <span className="font-bold text-3xl text-primary">{formatCurrency(cart?.total || 0)}</span>
                </div>
              </div>
              
              <div className="mt-8 flex items-center gap-3 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-700 rounded-xl">
                <ShieldCheck className="w-5 h-5 shrink-0" />
                <p className="text-xs font-medium">100% Secure Checkout backed by ShopHub Guarantee</p>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </MainLayout>
  )
}
