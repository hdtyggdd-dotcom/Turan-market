import { useState } from "react"
import { Link, useLocation, useParams } from "wouter"
import { 
  useGetProduct, 
  useAddToCart, 
  getGetCartQueryKey,
  useListProducts,
  getGetProductQueryKey,
  getListProductsQueryKey
} from "@workspace/api-client-react"
import { useQueryClient } from "@tanstack/react-query"
import { 
  Star, 
  ShoppingBag, 
  Minus, 
  Plus, 
  ChevronLeft, 
  Check, 
  Truck, 
  RotateCcw,
  ShieldCheck
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MainLayout } from "@/components/layout/MainLayout"
import { formatCurrency } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import { ProductCard } from "@/components/ProductCard"

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>()
  const productId = parseInt(id)
  const [, setLocation] = useLocation()
  const { toast } = useToast()
  const queryClient = useQueryClient()
  
  const [quantity, setQuantity] = useState(1)
  const [activeImage, setActiveImage] = useState(0)
  
  const { data: product, isLoading, isError } = useGetProduct(productId, {
    query: { enabled: !isNaN(productId), queryKey: getGetProductQueryKey(productId) }
  })
  
  // Get related products (same category)
  const { data: relatedProducts } = useListProducts({ categoryId: product?.categoryId }, {
    query: { enabled: !!product?.categoryId, queryKey: product?.categoryId ? getListProductsQueryKey({ categoryId: product.categoryId }) : undefined }
  })
  
  const addToCartMutation = useAddToCart()

  const handleAddToCart = () => {
    if (!product) return;
    
    addToCartMutation.mutate({
      data: {
        productId: product.id,
        quantity: quantity
      }
    }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() })
        toast({
          title: "Added to cart",
          description: `${quantity}x ${product.name} added to your cart.`,
          action: {
            label: "View Cart",
            onClick: () => setLocation('/cart')
          }
        })
      }
    })
  }

  if (isLoading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-8 md:py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-16">
            <div className="aspect-square bg-muted animate-pulse rounded-3xl" />
            <div className="space-y-6 pt-4">
              <div className="h-4 w-24 bg-muted animate-pulse rounded" />
              <div className="h-10 w-3/4 bg-muted animate-pulse rounded" />
              <div className="h-8 w-1/4 bg-muted animate-pulse rounded" />
              <div className="h-32 w-full bg-muted animate-pulse rounded" />
              <div className="flex gap-4">
                <div className="h-14 w-32 bg-muted animate-pulse rounded-full" />
                <div className="h-14 w-full bg-muted animate-pulse rounded-full" />
              </div>
            </div>
          </div>
        </div>
      </MainLayout>
    )
  }

  if (isError || !product) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-32 text-center flex flex-col items-center">
          <h1 className="font-serif text-4xl font-bold mb-4 text-foreground">Product Not Found</h1>
          <p className="text-muted-foreground mb-8 text-lg">The product you're looking for doesn't exist or has been removed.</p>
          <Button asChild size="lg" className="rounded-full">
            <Link href="/products">Back to Shop</Link>
          </Button>
        </div>
      </MainLayout>
    )
  }

  const discount = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) 
    : 0;

  // Prepare images array
  const images = product.images?.length 
    ? product.images 
    : product.imageUrl 
      ? [product.imageUrl] 
      : [];

  const otherRelatedProducts = relatedProducts?.filter(p => p.id !== product.id).slice(0, 4) || [];

  return (
    <MainLayout>
      <div className="bg-secondary/20 border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <button 
            onClick={() => window.history.back()} 
            className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            <ChevronLeft className="w-4 h-4 mr-1" />
            Back to previous
          </button>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-16">
          
          {/* Images */}
          <div className="space-y-4">
            <div className="aspect-square bg-muted rounded-3xl overflow-hidden relative border border-border shadow-sm">
              {images.length > 0 ? (
                <img 
                  src={images[activeImage]} 
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-secondary/50 text-muted-foreground">
                  <ShoppingBag className="w-20 h-20 opacity-20" />
                </div>
              )}
              
              <div className="absolute top-4 left-4 flex flex-col gap-2">
                {product.featured && (
                  <Badge className="bg-accent text-accent-foreground border-none font-medium px-3 py-1 text-sm shadow-md">Featured</Badge>
                )}
                {discount > 0 && (
                  <Badge variant="destructive" className="border-none font-medium px-3 py-1 text-sm shadow-md">
                    Save {discount}%
                  </Badge>
                )}
              </div>
            </div>
            
            {images.length > 1 && (
              <div className="grid grid-cols-5 gap-3">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImage(idx)}
                    className={`aspect-square rounded-xl overflow-hidden border-2 transition-all ${
                      activeImage === idx ? 'border-primary ring-2 ring-primary/20 ring-offset-1' : 'border-transparent hover:border-border'
                    }`}
                  >
                    <img src={img} alt={`${product.name} - view ${idx + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="flex flex-col py-2 md:py-6">
            <div className="mb-2">
              <a 
                href={`/products?categoryId=${product.categoryId}`}
                className="text-sm font-bold tracking-widest uppercase text-primary hover:text-primary/80 transition-colors"
              >
                {product.categoryName}
              </a>
            </div>
            
            <h1 className="font-serif text-3xl md:text-5xl font-bold text-foreground mb-4 leading-tight">
              {product.name}
            </h1>
            
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-bold text-foreground">{formatCurrency(product.price)}</span>
                {product.originalPrice && (
                  <span className="text-lg text-muted-foreground line-through decoration-muted-foreground/50">
                    {formatCurrency(product.originalPrice)}
                  </span>
                )}
              </div>
              
              <div className="h-6 w-px bg-border mx-2"></div>
              
              {product.rating && (
                <div className="flex items-center gap-1.5">
                  <div className="flex text-amber-500">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className={`w-4 h-4 ${star <= Math.round(product.rating!) ? 'fill-current' : 'fill-muted stroke-muted-foreground/30'}`} />
                    ))}
                  </div>
                  <span className="text-sm font-medium ml-1">{product.rating.toFixed(1)}</span>
                  <span className="text-sm text-muted-foreground">({product.reviewCount} reviews)</span>
                </div>
              )}
            </div>

            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              {product.description || "No description available for this product."}
            </p>

            {/* Actions */}
            <div className="border-y border-border py-8 mb-8 space-y-6">
              <div className="flex items-center justify-between">
                <span className="font-medium">Availability</span>
                {product.stock > 0 ? (
                  <span className="flex items-center text-emerald-600 bg-emerald-500/10 px-3 py-1 rounded-full text-sm font-medium">
                    <Check className="w-4 h-4 mr-1.5" /> In Stock ({product.stock})
                  </span>
                ) : (
                  <span className="text-destructive bg-destructive/10 px-3 py-1 rounded-full text-sm font-medium">
                    Out of Stock
                  </span>
                )}
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex items-center bg-secondary rounded-full h-14 p-1 w-full sm:w-36 flex-shrink-0">
                  <button 
                    type="button" 
                    className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-background transition-colors disabled:opacity-50"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    disabled={quantity <= 1 || product.stock === 0}
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="flex-1 text-center font-bold">{quantity}</span>
                  <button 
                    type="button" 
                    className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-background transition-colors disabled:opacity-50"
                    onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                    disabled={quantity >= product.stock || product.stock === 0}
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                
                <Button 
                  size="lg" 
                  className="flex-1 h-14 rounded-full text-base shadow-lg shadow-primary/20"
                  disabled={product.stock === 0 || addToCartMutation.isPending}
                  onClick={handleAddToCart}
                >
                  {addToCartMutation.isPending ? (
                    <span className="flex items-center"><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2"/> Adding...</span>
                  ) : product.stock === 0 ? (
                    "Sold Out"
                  ) : (
                    <span className="flex items-center"><ShoppingBag className="w-5 h-5 mr-2" /> Add to Cart — {formatCurrency(product.price * quantity)}</span>
                  )}
                </Button>
              </div>
            </div>

            {/* Guarantees */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-start gap-3 p-4 rounded-xl bg-secondary/50 border border-border">
                <Truck className="w-5 h-5 text-primary mt-0.5" />
                <div>
                  <h4 className="font-semibold text-sm">Fast Shipping</h4>
                  <p className="text-xs text-muted-foreground mt-1">Free delivery on orders over $100</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-4 rounded-xl bg-secondary/50 border border-border">
                <RotateCcw className="w-5 h-5 text-primary mt-0.5" />
                <div>
                  <h4 className="font-semibold text-sm">Easy Returns</h4>
                  <p className="text-xs text-muted-foreground mt-1">30 days risk-free return policy</p>
                </div>
              </div>
            </div>
            
          </div>
        </div>

        {/* Related Products */}
        {otherRelatedProducts.length > 0 && (
          <div className="mt-24 pt-16 border-t border-border">
            <div className="flex justify-between items-end mb-8">
              <h2 className="font-serif text-3xl font-bold text-foreground">You might also like</h2>
              <Button variant="ghost" asChild>
                <Link href={`/products?categoryId=${product.categoryId}`}>View more</Link>
              </Button>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {otherRelatedProducts.map(p => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  )
}
