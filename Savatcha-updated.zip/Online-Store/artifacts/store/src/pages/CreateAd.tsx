import { useState } from "react"
import { Link } from "wouter"
import { Megaphone, ImagePlus, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { MainLayout } from "@/components/layout/MainLayout"
import { useToast } from "@/hooks/use-toast"

export default function CreateAd() {
  const { toast } = useToast()
  const [name, setName] = useState("")
  const [price, setPrice] = useState("")
  const [description, setDescription] = useState("")
  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim() || !price.trim()) return
    const ads = JSON.parse(localStorage.getItem("savatcha_ads") || "[]")
    ads.unshift({ id: Date.now(), name, price, description, createdAt: new Date().toISOString() })
    localStorage.setItem("savatcha_ads", JSON.stringify(ads))
    toast({ title: "E'lon saqlandi", description: "E'loningiz profil ichida saqlandi." })
    setName(""); setPrice(""); setDescription("")
  }
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-10 max-w-2xl">
        <Link href="/profile" className="inline-flex items-center text-sm text-muted-foreground mb-6"><ArrowLeft className="h-4 w-4 mr-1"/> Profil</Link>
        <div className="rounded-3xl border bg-card p-6 md:p-8 shadow-sm">
          <div className="flex items-center gap-3 mb-7">
            <div className="h-11 w-11 rounded-xl bg-primary/10 text-primary flex items-center justify-center"><Megaphone /></div>
            <div><h1 className="font-serif text-3xl font-bold">E'lon yuklash</h1><p className="text-muted-foreground">Mahsulotni tez va sodda joylang.</p></div>
          </div>
          <form onSubmit={submit} className="space-y-5">
            <Input value={name} onChange={e=>setName(e.target.value)} placeholder="Mahsulot nomi" required />
            <Input value={price} onChange={e=>setPrice(e.target.value)} placeholder="Narxi (so'm)" inputMode="numeric" required />
            <Textarea value={description} onChange={e=>setDescription(e.target.value)} placeholder="Mahsulot haqida qisqacha..." className="min-h-32" />
            <div className="rounded-2xl border border-dashed p-5 text-center text-muted-foreground">
              <ImagePlus className="mx-auto mb-2 h-7 w-7" />
              <p className="text-sm">Rasm yuklash interfeysi tayyor. Serverga media saqlash ulanishi keyingi bosqichda qo‘shiladi.</p>
            </div>
            <Button type="submit" className="w-full h-12 rounded-full">E'lonni saqlash</Button>
          </form>
        </div>
      </div>
    </MainLayout>
  )
}
