import { useMemo, useState } from "react"
import { Link } from "wouter"
import { ArrowLeft, Bike, CarFront, MapPin, Package, Sparkles, Truck } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { MainLayout } from "@/components/layout/MainLayout"

type Vehicle = "car" | "scooter"

export default function Cargo() {
  const [vehicle, setVehicle] = useState<Vehicle>("car")
  const [distance, setDistance] = useState("10")
  const [volume, setVolume] = useState("0.5")

  const estimate = useMemo(() => {
    const km = Math.max(0, Number(distance) || 0)
    const m3 = Math.max(0, Number(volume) || 0)
    const base = vehicle === "scooter" ? 18000 : 30000
    const perKm = vehicle === "scooter" ? 2200 : 3500
    const volumeFee = Math.max(0, m3 - (vehicle === "scooter" ? 0.08 : 0.5)) * (vehicle === "scooter" ? 80000 : 60000)
    const total = Math.round((base + km * perKm + volumeFee) / 1000) * 1000
    const duration = Math.max(15, Math.round(km * (vehicle === "scooter" ? 4 : 3) + 10))
    return { total, duration }
  }, [vehicle, distance, volume])

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-10 max-w-3xl">
        <Link href="/" className="inline-flex items-center text-sm text-muted-foreground mb-6"><ArrowLeft className="h-4 w-4 mr-1"/> Bosh sahifa</Link>
        <div className="rounded-3xl border bg-card p-6 md:p-8 shadow-sm">
          <div className="flex items-center gap-3 mb-2">
            <div className="h-11 w-11 rounded-xl bg-primary/10 text-primary flex items-center justify-center"><Truck /></div>
            <h1 className="font-serif text-3xl font-bold">Yuk qo'shish</h1>
          </div>
          <p className="text-muted-foreground mb-8">Masofa va yuk hajmiga qarab transport hamda taxminiy narxni hisoblang.</p>

          <div className="grid grid-cols-2 gap-3 mb-7">
            <button type="button" onClick={()=>setVehicle("car")} className={`rounded-2xl border p-5 text-left transition ${vehicle==="car" ? "border-primary bg-primary/5" : "hover:bg-secondary"}`}>
              <CarFront className="h-7 w-7 mb-3 text-primary"/><b>Mashina</b><p className="text-xs text-muted-foreground mt-1">Kattaroq yuklar</p>
            </button>
            <button type="button" onClick={()=>setVehicle("scooter")} className={`rounded-2xl border p-5 text-left transition ${vehicle==="scooter" ? "border-primary bg-primary/5" : "hover:bg-secondary"}`}>
              <Bike className="h-7 w-7 mb-3 text-primary"/><b>Skuter</b><p className="text-xs text-muted-foreground mt-1">Kichik va tez yuk</p>
            </button>
          </div>

          <div className="grid sm:grid-cols-2 gap-5">
            <label className="space-y-2"><span className="text-sm font-medium flex items-center gap-2"><MapPin className="h-4 w-4"/> Masofa (km)</span><Input type="number" min="0" step="0.1" value={distance} onChange={e=>setDistance(e.target.value)}/></label>
            <label className="space-y-2"><span className="text-sm font-medium flex items-center gap-2"><Package className="h-4 w-4"/> Yuk hajmi (m³)</span><Input type="number" min="0" step="0.01" value={volume} onChange={e=>setVolume(e.target.value)}/></label>
          </div>

          <div className="mt-8 rounded-3xl bg-secondary/50 p-6">
            <div className="flex items-center gap-2 text-primary font-semibold mb-4"><Sparkles className="h-5 w-5"/> AI hisob-kitob</div>
            <div className="grid sm:grid-cols-2 gap-6">
              <div><p className="text-sm text-muted-foreground">Tavsiya etilgan transport</p><p className="text-xl font-bold mt-1">{vehicle === "car" ? "Mashina" : "Skuter"}</p></div>
              <div><p className="text-sm text-muted-foreground">Taxminiy narx</p><p className="text-2xl font-bold text-primary mt-1">{estimate.total.toLocaleString("uz-UZ")} so'm</p></div>
              <div><p className="text-sm text-muted-foreground">Taxminiy vaqt</p><p className="text-xl font-bold mt-1">{estimate.duration} daqiqa</p></div>
              <div><p className="text-sm text-muted-foreground">Hisoblash omillari</p><p className="text-sm font-medium mt-1">Masofa + hajm + transport turi</p></div>
            </div>
            <p className="text-xs text-muted-foreground mt-5">Narx taxminiy kalkulyatsiya. Haqiqiy narx manzil, yuk og‘irligi va haydovchi taklifiga qarab o‘zgarishi mumkin.</p>
          </div>
          <Button className="w-full h-12 rounded-full mt-6" onClick={()=>alert("Yuk so'rovi tayyor. Keyingi bosqichda haydovchi bilan bog'lash ulanadi.")}>Yuk so‘rovini yuborish</Button>
        </div>
      </div>
    </MainLayout>
  )
}
