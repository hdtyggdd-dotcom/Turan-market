# Savatcha — Play Market tayyorgarligi

Ilova nomi: **Savatcha**  
Android package ID: `uz.savatcha.app`

## Lokal AAB build

1. `pnpm install`
2. `cd artifacts/store`
3. `pnpm android:sync`
4. Android Studio orqali `android/` loyihasini oching.
5. Release signing key yarating va **Build > Generate Signed Bundle / APK > Android App Bundle** orqali `.aab` yarating.
6. Google Play Console'da yangi app ochib, `.aab` ni Internal testing orqali yuklang, keyin production release qiling.

> Play Market'ga chiqarish uchun Google Play Console akkaunti, developer verification, privacy policy va release signing kerak. Bu loyihada frontend/PWA va Capacitor konfiguratsiyasi tayyorlandi; imzolangan AAB va Play Console nashri tashqi hisob/kalitlar sabab avtomatik yaratilmaydi.
