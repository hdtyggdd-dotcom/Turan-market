# Savatcha yangilanishlari

- Eski ShopHub nomi olib tashlandi, yangi `Savatcha` brendi qo‘yildi.
- Mobil pastki navigatsiya 6 ta bo‘limga kengaytirildi: Qidiruv, Profil, E'lon, Yuk, Buyurtmalar, Savat.
- Aksiya va Shikastlangan tovarlar bo‘limlari qo‘shildi.
- Profil sahifasi qo‘shildi.
- E'lon yuklash sahifasi qo‘shildi.
- Yuk qo‘shish sahifasi qo‘shildi: Mashina/Skuter, masofa, yuk hajmi va avtomatik taxminiy narx/vaqt kalkulyatori.
- Savat mavjud backend bilan ishlaydi va buyurtmalar bilan bog‘langan.
- PWA manifest qo‘shildi.
- Capacitor konfiguratsiyasi qo‘shildi: Android App Bundle uchun `uz.savatcha.app`.
- Play Market chiqarish bo‘yicha `PLAY-MARKET.md` yo‘riqnomasi qo‘shildi.

Eslatma: real AI modeli va real haydovchi/masofa xaritasi integratsiyasi hali ulanmagan; hozirgi yuk kalkulyatori lokal formula asosida taxmin beradi.
